#OOP PHP Authentication System
==============================

Simple Login & Registration system using OOP PHP & Mysql. Created this for helping others who want to learn OOP PHP.

[Full Article Tutorial](http://www.w3programmers.com/login-and-registration-using-oop/)

