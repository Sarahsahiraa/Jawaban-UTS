<div class="jumbotron">
		<h2><center>Welcome Rumah Sakit Medika</center></h2>
	
</div>