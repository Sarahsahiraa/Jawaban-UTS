<!DOCTYPE html>
<html>
<head>
	<title>Medika Hospital</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="gambar/background.jpg">
 <h1>Rumah Sakit Medika</h1>
 
	<div class="kotak_login">
		<p class="tulisan_login">login User</p>
 
		<form method="post" action="action.php">
			<label>Username</label>
			<input type="text" name="username" class="form_login" placeholder="Username atau email ..">
 
			<label>Password</label>
			<input type="password" name="password" class="form_login" placeholder="Password ..">
 
			<input type="submit" class="tombol_login" value="LOGIN">
				
		</form>
		
	</div>
 
 
</body>
</html>